# ASRenum

Identify ASR rules, actions, and exclusion locations

Thanks to [EspressoCake](https://github.com/EspressoCake/Defender_Exclusions-BOF)

## ASRenum-BOF.cpp/.cna

```
$ make all
```
- load cna

![Screenshot from 2022-12-28 14-05-34](https://user-images.githubusercontent.com/47215311/209824105-faa90ec2-3738-4db1-b7aa-c3f4f22bbf8a.png)


### ASRenum.cpp
- initial script

### ASRenum.cs
- todo: test BOF.NET